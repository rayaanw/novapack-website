# Upload Instructions — Novapack Landing Page

## cPanel / shared hosting
1. Unzip this package.
2. Open your hosting File Manager and go to `public_html`.
3. Back up any existing homepage file.
4. Upload `index.html` to `public_html`.
5. Upload `assets/` and `docs/` folders as backup/reference folders.
6. Clear any site/cache plugin or browser cache.

## Terminal / SSH upload example
Replace `USERNAME` and `SERVER` with your hosting details.

```bash
scp index.html USERNAME@SERVER:/home/USERNAME/public_html/index.html
scp -r assets USERNAME@SERVER:/home/USERNAME/public_html/
scp -r docs USERNAME@SERVER:/home/USERNAME/public_html/
```

## Local preview
From inside the unzipped folder:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000` in your browser.

## Image note
The major custom visuals are embedded in `index.html`. Existing online product-image URLs are listed in `EXTERNAL_IMAGE_URLS_USED.txt`.
