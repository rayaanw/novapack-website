NOVAPACK FINAL WEBSITE UPLOAD PACKAGE
Prepared: 2026-06-03

WHAT TO UPLOAD
==============
Required:
- index.html

Recommended backup/reference folder:
- assets/images/

Documentation:
- docs/UPLOAD_INSTRUCTIONS.md
- docs/EXTERNAL_IMAGE_URLS_USED.txt

IMPORTANT
=========
The header logo, hero image, About-section image, and the GRS/RCS Sustainability certificate are embedded directly in index.html, so they display from the HTML file itself.

Several product images are already linked to online URLs. These images do not need to be uploaded for this HTML version to display while those URLs remain available. Their URL list is included in docs/EXTERNAL_IMAGE_URLS_USED.txt.

Folder structure:
/
  index.html
  assets/
    images/
  docs/
